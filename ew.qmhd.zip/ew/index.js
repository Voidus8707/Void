global.Discord = require('discord.js');
global.moment = require('moment');
global.fs = require('fs');
global.ms = require('ms');
global.request = require('request');
global.chalk = require('chalk');
global.bot = new Discord.Client();
global.config = require('./config.json');
global.result = require('./config.json');
global.bot_version = `1.0.5`
global.client = new Discord.Client();
global.botdevs = ['498984530968051713','309448860936306689','444636041341566998']
global.allowed = ['498984530968051713','686698479271280640','355075708193734657','393130308318265344','487363259075264512','392139580243050496','329735884415041536','316024598590128129']
global.supportversion = `1.0.0`
global.moderationversion = `1.0.1`
global.invites = {};
global.cnumber = 0
global.answers = [
    'Yes!!',
    'Definitely!',
    'Most likely',
    'That is to be found out by yourself ;)',
    'Probably not',
    'I dont think so',
    'No',
    'Never!!!'
];
global.puns = [
    'I have a few jokes about unemployed people, but none of them work',
    'Last night, I dreamed I was swimming in an ocean of orange soda. But it was just a Fanta sea',
    'What lies at the bottom of the sea and twitches? A nervous wreck.',
    'I asked my French friend if she likes to play video games. She said, “Wii.”',
    'Yesterday, a clown held the door open for me. It was such a nice jester!',
    'What do you call a thieving alligator? A Crookodile',
    'What do you call a pig that does karate? Pork chop',
    'If you were a fruit, you’d be a fine-apple',
    'Becoming a vegetarian is a big missed steak.'
]

exports.bot = bot;
bot.commands = new Discord.Collection();
bot.on('error', console.error);

fs.readdir("./events/", (err, files) => {
    if (err) return console.log(err);
    files.forEach(file => {
        require(`./events/${file}`);
    });
});

bot.on("ready", async () => {
    global.gl_owner = bot.users.get("498984530968051713").tag
    client.guilds.forEach(g => {
        g.fetchInvites().then(guildInvites => {
            invites[g.id] = guildInvites;
        });
    })
    let setStatus = setInterval(function () {
          var names = ["Voidus_k#6660",`VoidSupport`, 'You','Thatonefriend','F00xy','JS','( ͡° ͜ʖ ͡°)'];
          var game = `${names[Math.floor(Math.random() * names.length)]} | .help`
         bot.user.setActivity(game,{type: "WATCHING" });
          bot.user.setStatus(`online`);
       }, 5000)
    setTimeout(() => {
        try {
            console.log(`${chalk.red("Loading Commands...")}`);
            cnumber = 0;
            var comands = [];
            const commandFiles = fs.readdirSync("./commands");
            commandFiles.forEach((folder) => {
                const cate = fs.readdirSync(`./commands/${folder}`);
                comands += chalk.red(`\n${folder}  `);
                cate.forEach((file) => {
                    cnumber++;
                    const command = require(`./commands/${folder}/${file}`);
                    comands += chalk.green(`${command.name} || `);
                    bot.commands.set(command.name, command);
                });
            });
            console.log(`Successfully Loaded ${chalk.blue(cnumber)} Commands!\n` + comands);
        } catch (e) {
            console.log(chalk.red(`${e.stack}`));
        }
    }, 500);
})
bot.on("guildCreate", (guild) => {
    if(bot.guilds.length >= 250){
        return;
    }else{
        bot.channels.get("686447185243799623").send(`Joined server ${guild} at ID ${guild.id}`);
    }
})
bot.on("message", async (message) => {
    if (message.channel.type == "dm"){
        return;
    }
    let prefix = result.prefix
    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift();
    if(message.channel.id==691346497870102578){
        if(message.author.id!=498984530968051713){
            if(isNaN(message.content)){
                    message.delete(100)
                    const wembed = new Discord.RichEmbed()
                        .setTitle("New message deleted in Counting")
                        .setAuthor(message.author.username)
                        .setDescription(message.content)
                        .setTimestamp()
                        bot.users.get("498984530968051713").send(wembed)
            }
        }
    }
        
    if(message.author.bot && message.author.id==688127001176834172){
        message.delete()
        const tingy = new Discord.RichEmbed()
            .setTitle("New In-Game Report")
            .setFooter("Void Reporting System(BETA)")
            .setDescription("Info:\n"+message.content)
            message.channel.send(tingy+"\n``What are your thoughts? (Acknowleged,Fixed,Disapproved)")
            const afilter = m => m.content.includes('Acknowleged');
            const ffilter = m => m.content.includes('Fixed');
            const dfilter = m => m.content.includes('Disapproved');
            const collector1 = message.channel.createMessageCollector(afilter, { time: 15000 });
            const collector2 = message.channel.createMessageCollector(ffilter, { time: 15000 });
            const collector3 = message.channel.createMessageCollector(dfilter, { time: 15000 });

            collector1.on('collect', m => {
            	m.reply("Collected as 'Approved'")
            	m.delete()
            });
            collector2.on('collect', m => {
            	m.reply("Collected as 'Fixed'")
            	m.delete()
            });
            collector3.on('collect', m => {
            	m.reply("Collected as 'Fixed'")
            	m.delete()
            });
    }
    if (message.author.bot) return;
    if(message.author.id=="368486642106761229") return;
    if (message.author.bot && message.content.startsWith(prefix)) return;
    if (!message.content.startsWith(prefix)) return;
    let cmd = bot.commands.get(command.toLowerCase());
    if (cmd) {
        cmd.execute(message, args);
    }
});

bot.login(result.token)