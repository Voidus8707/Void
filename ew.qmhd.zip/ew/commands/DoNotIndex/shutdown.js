module.exports = {
    name: "shutdown",
    desc: "Exits the process of the bot",
    usage: "<reason>",
    cooldown: 5,
    execute: async (message, args) => {
        const REE = new Discord.RichEmbed()
            .setTitle("🚫Error")
            .setDescription("Please specify a reason.")
            .setTimestamp()
        var reason = message.content.split(' ').slice(1).join(' ');
        if(!reason){ return message.channel.send(REE)}
        if (allowed.some(link => message.author.id.toLowerCase().includes(link))) {
            message.channel.send("Killing bot process.")
            console.log(chalk.bgRed(`Bot shutting down:\nReason: "${reason}"\nUser: ${message.author.username}\nGuildname/ID: ${message.guild.name} // ${message.guild.id}`))
            setTimeout(function e(){process.exit()},1000);
        }else{
            const embed = new Discord.RichEmbed()
                .setAuthor("PermissionMenu")
                .setDescription("Sorry, you are not allowed to use this command.")
                .setFooter("ERROR:ALLOWED-LIST:FALSE")
                message.channel.send({embed});
        }
    }
}