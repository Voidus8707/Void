module.exports = {
    name: "refresh",
    desc: "Refresh the bot (soft restart)",
    usage: "",
    cooldown: 5,
    execute: async (message, args) => {
    message.delete();
    
    message.channel.send('Refreshing');
    console.clear();
    bot.destroy();
    bot.login(config.token);
    
    message.channel.send('I have refreshed!')

}}