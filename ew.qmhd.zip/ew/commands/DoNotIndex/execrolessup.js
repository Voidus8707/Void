module.exports = {
    name: "addsup",
    desc: "Add support roles",
    usage: "<PREDETERMINED:-add>",
    cooldown: 5,
    execute: async (message, args) => {
    process.emitWarning(`${message.member} is adding support roles on ${message.guild.id} with name ${message.guild.name}`)
        var mainrole = message.guild.roles.find(r=>r.name==="Voidbot Support")
        if(!mainrole){
            muterole = await message.guild.createRole({
                name: "Voidbot Support",
                color: [255,0,0],
                permissions:[],
                position: 1
            })
            message.guild.channels.forEach(channel =>{
                channel.overwritePermissions(mainrole,{
                    "READ_MESSAGES": true,
                    "SEND_MESSAGES": true,
                    "MANAGE_MEMBERS": true
                })
            })
            message.member.addRole(mainrole)
        }else{
            message.member.addRole(mainrole)
        }
}}