module.exports = {
    name: "eval",
    desc: "Run code",
    usage: "<javascript>",
    cooldown: 5,
    execute: async (message, args) => {
    
    const clean = text => {
        if (typeof(text) === "string")
          return text.replace(/`/g, "`" + String.fromCharCode(8203)).replace(/@/g, "@" + String.fromCharCode(8203));
        else
            return text;
    }
    
    if(message.author.id == 498984530968051713){
        try {
                const code = args.join(" ");
                let evaled = eval(code);
            
                if (typeof evaled !== "string")
                    evaled = require("util").inspect(evaled);
                    const uwumbed = new Discord.RichEmbed()
                        .setAuthor(`Evalutation by ${message.author.tag}`)
                        .setDescription(`**:regional_indicator_i: Input:**\n\n\`\`\`js\n${code}\`\`\``, true)
                        .addField(`\u200b`, `**:regional_indicator_o: Output:**\n\n\`\`\`js\n${clean(evaled)}\`\`\``, true)
            
                message.channel.send(uwumbed);
                } catch (err) {
                message.channel.send(`\`ERROR\` \`\`\`xl\n${clean(err)}\n\`\`\``);
                }
    }else if(message.author.id == 641795527444529152){
        try {
                const code = args.join(" ");
                let evaled = eval(code);
            
                if (typeof evaled !== "string")
                    evaled = require("util").inspect(evaled);
                    const uwumbed = new Discord.RichEmbed()
                        .setAuthor(`Evalutation by ${message.author.tag}`)
                        .setDescription(`**:regional_indicator_i: Input:**\n\n\`\`\`js\n${code}\`\`\``, true)
                        .addField(`\u200b`, `**:regional_indicator_o: Output:**\n\n\`\`\`js\n${clean(evaled)}\`\`\``, true)
            
                message.channel.send(uwumbed);
                } catch (err) {
                message.channel.send(`\`ERROR\` \`\`\`xl\n${clean(err)}\n\`\`\``);
                }
    }else{
            message.channel.send("Sorry "+message.author.username+", only Void can run that command!")
    }
}}