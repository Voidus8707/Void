const talkedRecently = new Set();
        
        module.exports = {
            name: "report",
            desc: "Report a bug in the bot to the support server.",
            usage: "",
            cooldown: 5,
            execute: async (message, args) => {
        message.delete();

        const cooldownEmbed = new Discord.RichEmbed()
            .setColor(`RED`)
            .setTitle(`⛔ You already reported an issue recently, please wait another 30 minutes`)
        const tooshortEmbed = new Discord.RichEmbed()
            .setColor(`RED`)
            .setTitle(`⛔ Please provide a message`)
            .setFooter(`Message must be longer than 10 characters`)
        const thanksEmbed = new Discord.RichEmbed()
            .setColor(`GREEN`)
            .setTitle(`✅ Your bug report has been sent. Thanks!`)

        if (talkedRecently.has(message.author.id)) return message.channel.send(cooldownEmbed).then(msg => msg.delete(5000));
                        let feedback = args.join(' ');
                            if (feedback.length < 10) return message.reply(tooshortEmbed).then(msg => msg.delete(5000));

                        const bugembed = new Discord.RichEmbed()
                        .setColor(`RED`)
                        .setAuthor(`🐛Bug Report`)
                        .setTitle(`> ${feedback}`)
                        .setDescription(`*by: ${message.author.tag}*`)
                        .setTimestamp()

                        bot.guilds.get(`686435271696187394`).channels.get(`695293203792003163`).send(bugembed).then(sentEmbed => {
                            sentEmbed.react("✅")
                            .then (() => sentEmbed.react("❔"))
                            .then (() => sentEmbed.react("❌"))
                        });
                            message.reply(thanksEmbed).then(msg => {msg.delete(5000)});
                    talkedRecently.add(message.author.id);
                    setTimeout(() => {
                        talkedRecently.delete(message.author.id);
                    }, 30 * 60000);
            }
        }