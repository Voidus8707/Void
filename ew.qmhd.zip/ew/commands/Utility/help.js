module.exports = {
  name: "help",
  desc: "Shows this list.",
  usage: "`<command>`",
  cooldown: 5,
  execute: async (message, args) => {
    let prefix = result.prefix
    var ncomands = [];
    let embed = new Discord.RichEmbed();
    embed.setTimestamp().setFooter(`Void`, bot.user.avatarURL)
    embed.setTimestamp();
    embed.setAuthor("Void's Commands:")
    embed.setThumbnail(bot.user.avatarURL);
    embed.setColor("RANDOM")
    const commandFiles = fs.readdirSync("./commands");
    commandFiles.forEach((folder) => {
      var cnumber = 0;
      if (folder == "DoNotIndex") return;
      var ccommands = []
      const cate = fs.readdirSync(__dirname + `/../${folder}`);
      ncomands += `\n**${folder}**:\n`
      cate.forEach((file) => {
        cnumber++;
        const command = require(__dirname + `/../${folder}/${file}`);
        ccommands += ` \`${command.name}\``
      })
      embed.addField(`${folder} (${cnumber})`, ccommands.slice(1).replace(/ /g, ", ") + ".")
    });
    embed.addField("Our Website","[Support]( http://voidus.ga:2004/bots/void/support )")

    if (!args[0]) return message.channel.send(embed)

    else {
      let hembed = new Discord.RichEmbed()
      hembed.setColor("RANDOM")
      hembed.setThumbnail(bot.user.avatarURL)
      hembed.setTimestamp().setFooter(`Void`, bot.user.avatarURL)
      hembed.setTimestamp()
      hembed.setDescription("Void")
      var cmdnumb = 0
      commandFiles.forEach((folder) => {
        if (folder == "DoNotIndex") return;
        const cate = fs.readdirSync(__dirname + `/../${folder}`);
        cate.forEach((file) => {
          const command = require(__dirname + `/../${folder}/${file}`);
          let usage = `\`${prefix}${command.name} ${command.usage}\``
          if (command.name == args[0].toLowerCase()) {
            cmdnumb++;
            hembed.setAuthor(args[0].toLowerCase())
            hembed.addField("**Command:**", `Name: ${command.name}\nDescription: ${command.desc}\nUsage: \`${usage}\``)
          }
        })
      })
      if (cmdnumb == 0) {
        hembed.setAuthor(`Cuddle Master`)
        hembed.addField(`**__Couldn't Find the command ${args[0]}__**`, `Double check the command list and spelling! If you think there is a problem feel free to report it in our support server!`)
      }
      message.channel.send(hembed)
    }

  }
}