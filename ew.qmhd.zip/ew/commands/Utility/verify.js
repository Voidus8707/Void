module.exports = {
    name: "verify",
    desc: "verify yourself nerd",
    usage: "",
    cooldown: 5,
    execute: async (message, args) => {
    if(message.guild.id!="686304811632689225") return message.reply("Wrong server.")
    if(message.channel.id!="694663881393569892") return message.reply("Please use the correct channel.").then(m=>m.delete(10000))
    if(message.member.roles.has("694666514707644456")) return message.reply("You already are verified").then(m=>m.delete(10000))
    await message.member.addRole("694666514707644456")
    message.reply("You are now verified.").then(m=>m.delete(10000))
}}