module.exports = {
    name: "serveremojis",
    desc: "Returns a list with server's emojis",
    usage: "",
    execute: async (message, args) => {
        message.delete();
        const noemojiEmbed = new Discord.RichEmbed()
            .setColor(`RED`)
            .setTitle(`⛔ Server has no emojis`)
        const emoji = message.guild.emojis;
        if (!emoji.size) return message.channel.send(noemojiEmbed).then(msg => msg.delete(5000));
        const embed = new Discord.RichEmbed()
            .addField("Server Emojis", emoji.map((e) => e).join(' '))
            .setAuthor(`Requested by ${message.author.tag}`)
        message.channel.send({embed})
    }
}