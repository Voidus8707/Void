module.exports = {
    name: "ping",
    desc: "Check the bot's ping time",
    usage: "",
    cooldown: 5,
    execute: async (message, args) => {
        const embed = new Discord.RichEmbed()
        .setColor("RANDOM")
        .addField("Pong!", new Date().getTime() - message.createdTimestamp + " ms")
        .setFooter(`Latency Check`, bot.user.avatarURL)
        message.channel.send({embed});
    }
}