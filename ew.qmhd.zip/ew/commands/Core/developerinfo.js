const fs = require("fs");
const os = require('os');
const cpuStat = require("cpu-stat");
module.exports = {
    name: "dev.botinfo",
    desc: "Get stats for the bot",
    usage: "",
    execute: async (message, args) => {
        message.delete(2000)
        if(!botdevs.find(ting=>ting===message.author.id)){
            const errorbedder = new Discord.RichEmbed()
            .setTitle('Invalid Permissions')
            .setColor([255,0,0])
            .setDescription('Only bot developers can see the bot\'s status.')
            .setTimestamp().setAuthor("VoidError")
            return message.channel.send(errorbedder)
        }
    cpuStat.usagePercent(function(err, percent, seconds) {
            if (err) {
              return console.log(err);
            }
            const embed = new Discord.RichEmbed()
                .setAuthor(bot.user.username)
                .setColor(`RANDOM`)
                .setThumbnail(bot.user.avatarURL)
                .addField('Bot Created', bot.user.createdAt.toLocaleString(), true)//
                .addField('Bot Owner', gl_owner,true)
                .addField('Bot Version',bot_version,true)
                .addField('Total Servers', Math.ceil(bot.guilds.size), true)
                .addField('Total Users', `${bot.users.size}`, true)
                .addField('Total Channels:', `${bot.channels.size}`, true)
                .addField('Total Commands:',cnumber,true)
                .addField('Node.js Version', process.version, true)
                .addField("CPU", `\`\`\`${os.cpus().map(i => `${i.model}`)[0]}\`\`\``, true)//
                .addField("CPU usage", `\`${percent.toFixed(2)}%\``,true)//
                .addField("RAM", `\`${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB\``, true)
                .addField("Arch", `\`${os.arch()}\``,true)//
                .addField("Platform", `\`${os.platform()} ${os.release}\``,true)
                .setTimestamp()
                .setFooter(bot.user.username, bot.user.avatarURL);
            message.channel.send({embed});
        })}};