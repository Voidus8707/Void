module.exports = {
    name: "uptime",
    desc: "Returns bot uptime from start",
    usage: "",
    execute: async (message, args) => {

let totalSeconds = (message.client.uptime / 3600);
let days = Math.floor(totalSeconds / 86400);
let hours = Math.floor(totalSeconds / 3600);
totalSeconds %= 3600;
let minutes = Math.floor(totalSeconds / 60);
let seconds = Math.round(totalSeconds % 60);
let uptime = `${days} days, ${hours} hours, ${minutes} minutes and ${seconds} seconds`;
const embed = new Discord.RichEmbed()
    .setAuthor(message.client.user.username)
    .setDescription(uptime)
    .setFooter("Uptime Check")
    message.channel.send({embed});
}};