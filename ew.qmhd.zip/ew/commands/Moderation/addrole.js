module.exports = {
    name: "addrole",
    aliases: ["grant"],
    category: "Roles",
    desc: "Grant a role to users",
    usage: "<user-mention> <role>",
    permission: "MANAGE_ROLES",
    execute: async (message, args) => {
        message.delete();

        const nopermEmbed = new Discord.RichEmbed()
            .setColor(`RED`)
            .setTitle(`⛔ You don't have permission to use this!`)
        const noargsEmbed = new Discord.RichEmbed()
            .setColor(`RED`)
            .setTitle(`⛔ Please mention a valid user of this server and provide a role`)
        const noroleEmbed = new Discord.RichEmbed()
            .setColor(`RED`)
            .setTitle(`⛔ Couldn't find that role`)

        if (!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send(nopermEmbed).then(msg => msg.delete(5000));
        let rMember = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
        let role = args.join(" ").slice(22);
        if (!rMember || !role) return message.channel.send(noargsEmbed).then(msg => msg.delete(5000));
        let gRole = message.guild.roles.find(grole => grole.name === role);
        if (!gRole) return message.channel.send(noroleEmbed).then(msg => msg.delete(5000));

        const alreadyEmbed = new Discord.RichEmbed()
            .setColor(`RED`)
            .setTitle(`⛔ ${rMember} already has that role`)

        if (rMember.roles.has(gRole.id)) return message.channel.send(alreadyEmbed).then(msg => msg.delete(5000));
        await (rMember.addRole(gRole.id));

        const doneEmbed = new Discord.RichEmbed()
            .setColor(`GREEN`)
            .setTitle(`✅ **${grole.name}** has been given to <@${rMember.id}`)

        message.channel.send(doneEmbed);
    }
}