module.exports = {
    name: "pun",
    desc: "Get a pun",
    usage: "",
    execute: async (message, args) => {
     message.channel.send(puns[Math.floor(Math.random() * puns.length)])
}};