module.exports = {
    name: "eightball",
    desc: "Find out questions no one knows the answers to except eightball!",
    usage: "<question>",
    alias: "8ball",
    execute: async (message, args) => {
        message.channel.send(answers[Math.floor(Math.random() * answers.length)])
}};